### Rentit

Rentit is an Android application allowing user to rent their possessions to other people to other users. This is intended for people who need to rent a specific object for a temporary period, and for people who want to make some extra cash from their unused possessions. 

### Members

Danyaal Patel, Kei Nakano, Kenneth Liang, Rashid Qawasme

### Video Links

<!---(Replace the link here with the Youtube link)-->
[Original Pitch](https://youtu.be/DCBdJQeRkQI)

[Rentit Show and Tell 1](https://youtu.be/qP5KhkwnlbM)

[Rentit Show and Tell 2](https://youtu.be/ohoBv5kA1M8)

[Presentation video](https://youtu.be/4z5gA4ksUIs)
### Download
<a href="Rentit.apk">Download App apk</a>
Work in progress, coming soon! 
