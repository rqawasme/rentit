# Rentit

Rentit is an Android application allowing user to rent their possessions to other people to other users. This is intended for people who need to rent a specific object for a temporary period, and for people who want to make some extra cash from their unused possessions.
