Installation
------------

	* Simply download the app apk file to your android phone by clicking on the 'Download app apk' hyperlink on the webpage




Disclaimers
-----------
	* There's small UI differences between the demo videos and the release app, these are only UI changes
	* The app is developed and tested in Android 11, switching to Android 12 may cause some Toast messages to be cut off. In Android 12, the Toast view has been redesigned and toasts are limited to two lines of text.
	* Please allow all permissions the app requests for an awesome use experience




Resources/ Links
----------------
	
	* Project webpage: https://rqawasme.github.io/rentit/